package Assignment11;

public class Student {
	
	// QUESTION 3

	String name;
	int rollNo;
	int age;
	
	
	public Student(String name, int rollNo, int age) {
		this.name = name;
		this.rollNo = rollNo;
		this.age = age;
	}
	
	
}
