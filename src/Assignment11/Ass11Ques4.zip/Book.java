package Assignment11;

public class Book {
	
	// QUESTION 4

	Integer id;
	String name;
	String author;
	String publisher;
	
	Book(){}
	
	Book(Integer id,String name, String author, String publisher) {
		this.id =id;
		this.name=name;
		this.author = author;
		this.publisher = publisher;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
