package Assignment11;

public class Company {
	
	// QUESTION 2
	
	int compId;
	String companyName;
	String compPhone;
	String compEmail;
	String compInfo;
	
	Company() {}
	
	Company(int compId, String companyName, String compPhone, String compEmail, String compInfo) {
		this.compId = compId;
		this.companyName = companyName;
		this.compPhone = compPhone;
		this.compEmail = compEmail;
		this.compInfo = compInfo;
	}

}
